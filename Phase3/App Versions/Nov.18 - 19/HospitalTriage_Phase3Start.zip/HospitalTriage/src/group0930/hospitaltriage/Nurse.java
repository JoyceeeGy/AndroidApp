package group0930.hospitaltriage;

/**
 * A User with the authority of a nurse
 */

public class Nurse extends User{

	/**
	 * Add patientRecord to all the patients' records in patient_records.txt. 
	 */
	public void addPatientRecord(String[] patientRecord){
	}
	
	public String[][] getToHelpPatients(){
		return null;
	}
}
