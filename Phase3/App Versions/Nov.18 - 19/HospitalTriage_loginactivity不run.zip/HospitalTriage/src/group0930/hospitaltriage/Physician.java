package group0930.hospitaltriage;

/**
 * A User with the authority of a nurse
 */

public class Physician extends User {

	public String getPrescription(String healthCardNum){
		return null;
	}
	public void updatePrescription(String healthCardNum, String prescription){
	}
}
