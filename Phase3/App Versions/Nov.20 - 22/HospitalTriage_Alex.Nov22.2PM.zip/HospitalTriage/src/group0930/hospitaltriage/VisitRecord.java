//	This is the menu of VisitRecord which contains specific information 
//	of one single visit record of a patient.
//	
//	In this menu, the app shows the specific information of one single visit record of a patient,
//	including:	Date of visit,
//				Age
//				Temperature
//				Systolic Blood Rate
//				Diastolic Blood Rate
//				Heart Rate
//				Urgency Level
//				
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class VisitRecord extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_visit_record);
		Intent intent = getIntent();
		String[] visitdate = (String[]) intent.getSerializableExtra("visitrecord"); 
		String name = (String) intent.getSerializableExtra("name");
		String urgencylvl = (String) intent.getSerializableExtra("urgencylvl"); 
		
		populatelist(name,urgencylvl,visitdate);
		
		returnactivity();

	}

	private void populatelist(String name,String urgencylvl, String[] visitdate) {

		// Setting thisPatient's info on the View
		
		TextView header = (TextView) findViewById(R.id.headerofonerecord);
		header.append("  "+name+"\nDate:"+ visitdate[0]);
		
		TextView age = (TextView) findViewById(R.id.age);
		age.append("  "+  visitdate[1]);
		
		TextView temp = (TextView) findViewById(R.id.temp);
		temp.append("  "+  visitdate[2]);
		
		TextView sblood = (TextView) findViewById(R.id.sblood);
		sblood.append("  "+  visitdate[3]);
		
		TextView dblood = (TextView) findViewById(R.id.dblood);
		dblood.append("  "+  visitdate[4]);
		
		TextView heartrate = (TextView) findViewById(R.id.heartrate);
		heartrate.append("  "+  visitdate[5]);
		
		TextView urgencylevel = (TextView) findViewById(R.id.urgencylvl);
		urgencylevel.append("  "+  urgencylvl);
	
	}
	
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
	
	
	
}
