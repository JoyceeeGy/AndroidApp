//	This is the menu of PatientList which contains a list of all patients.
//	
//	In this menu, user can view a list that contains all the patients,
//	each item of the list contains one patient with his/her 
//	health card number, name and date of birth.
//	
//	By click each item of the list(each patient), 
//	the app will open a menu of that patient's PatientProfile.
//			
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PatientList extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_patient_list);
		
		populatelist();
		viewprofile ();
		
		returnactivity();
	  }
		
	
	private void populatelist() {
		
		User currentUser = new User();
		String [][] data = currentUser.getPatientsData();
		
		ArrayList<String> pRecordsAL = new ArrayList<String>();
		String temp = "";
		for (String[] arr: data){
			temp = "";
			for (String s: arr){
				temp += s + " ";
			}
			pRecordsAL.add(temp);
		}
		
		ArrayAdapter<String> pladapter = new ArrayAdapter<String>(this,R.layout.patientinlist,pRecordsAL);
		ListView list = (ListView) findViewById(R.id.patientlist);
		list.setAdapter(pladapter);
	}
		

	
	
	private void viewprofile () {
		ListView list = (ListView) findViewById(R.id.patientlist);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			//@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				TextView txt = (TextView) view;
				String hcn = txt.getText().toString().split(" ")[0];
				
				String message = "Viewing profile of "+ txt.getText().toString();
				Toast.makeText(PatientList.this,message,Toast.LENGTH_LONG).show();
				
				
				Intent intent = new Intent(PatientList.this, PatientProfile.class);
				intent.putExtra("patientnumber", hcn);
				startActivity(intent);
			}
		});
	}
	
	
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
	
}
