package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class NewPatientRecord extends Activity {

	private Nurse currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_new_patient_record);
		
		Intent intent = getIntent();
		currentUser = (Nurse) intent.getSerializableExtra("user");
		
		
		this.createRecord();
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		
		TextView newpatienttitle = (TextView) findViewById(R.id.newpatienttitle);
		newpatienttitle.setTypeface(helv);
		newpatienttitle.setTextSize(24);
		
		TextView newlastname = (TextView) findViewById(R.id.newlastname);
		newlastname.setTypeface(helv);
		newlastname.setTextSize(18);
		
		TextView newfirstname = (TextView) findViewById(R.id.newfirstname);
		newfirstname.setTypeface(helv);
		newfirstname.setTextSize(18);
		
		TextView newdob = (TextView) findViewById(R.id.newdob);
		newdob.setTypeface(helv);
		newdob.setTextSize(18);
		
		TextView newhcn = (TextView) findViewById(R.id.newhcn);
		newhcn.setTypeface(helv);
		newhcn.setTextSize(18);
		
		TextView addpatient = (TextView) findViewById(R.id.addpatient);
		addpatient.setTypeface(helv);
		addpatient.setTextSize(20);
		
		TextView Cancel = (TextView) findViewById(R.id.Cancel);
		Cancel.setTypeface(helv);
		Cancel.setTextSize(20);
		
	}
	
	public void createRecord(){
		
		Button addrecord = (Button) findViewById(R.id.addpatient);
		addrecord.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				
				String[] patient_record = new String[3];
				
				EditText lastnametxt = (EditText) findViewById(R.id.enterlastname);
				String lastname = lastnametxt.getText().toString();
				
				EditText firstnametxt = (EditText) findViewById(R.id.enterfirstname);
				String firstname = firstnametxt.getText().toString();
				
				EditText dobtxt = (EditText) findViewById(R.id.enterdob);
				String dob = dobtxt.getText().toString();
				if (!dob.matches("^\\d{4}-\\d{2}-\\d{2}$")){
					String msg = "Invalid Format for Date of Birth";
					Toast.makeText(NewPatientRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText hcntxt = (EditText) findViewById(R.id.enterhcn);
				String hcn = hcntxt.getText().toString();
				if (!hcn.matches("^\\d{6}$")){
					String msg = "Invalid Health Card Number";
					Toast.makeText(NewPatientRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				String name = firstname + " " + lastname;
				
				// Get inputs from EditText(s)��and save them into patient_record as follow
				patient_record[0] = hcn;
				patient_record[1] = name;
				patient_record[2] = dob;

				// Remember to pass in the Patient object from the Patient Profile activity
				currentUser.addPatientRecord(patient_record);
				Patient thisPatient = currentUser.getPatient(hcn);
				
				
				// Open a new Patient Profile activity (so the visit records would reload)
				Intent intent = new Intent(NewPatientRecord.this, PatientProfile.class);
				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);
				finish();
				startActivity(intent); 
				
			    }
			});
	}
	
	
	public void Cancel(View view) {
		 finish();
	}
}
