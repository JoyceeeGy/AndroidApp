package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DoctorActivity extends Activity {

	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_doctor);
		
		
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		
		this.addPrescription(thisPatient);
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		
		TextView title = (TextView) findViewById(R.id.title);
		title.setTypeface(helv);
		title.setTextSize(24);
		
		TextView save = (TextView) findViewById(R.id.save);
		save.setTypeface(helv);
		save.setTextSize(20);
		
		TextView cancel = (TextView) findViewById(R.id.cancel);
		cancel.setTypeface(helv);
		cancel.setTextSize(20);
		
	}

	
	
	public void addPrescription(final Patient thisPatient) {

		Button bn = (Button) findViewById(R.id.save);
		bn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				EditText dateText = (EditText) findViewById(R.id.date);
				EditText timeText = (EditText) findViewById(R.id.time);
				String date = dateText.getText().toString();
				String time = timeText.getText().toString();
				
				if (!date.matches("^\\d{4}-\\d{2}-\\d{2}$")){
					String msg = "Invalid Format for Date";
					Toast.makeText(DoctorActivity.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				if (!time.matches("^\\d{2}-\\d{2}$")){
					String msg = "Invalid Format for Time";
					Toast.makeText(DoctorActivity.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				thisPatient.addDoctorRecord(new String[]{date, time, "YES"});
				
				Intent intent = new Intent(DoctorActivity.this,
						NewPrescription.class);
				if (currentUser.isNurse()){
					intent = new Intent(DoctorActivity.this, PatientProfile.class);
				}

				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);

				finish();
				startActivity(intent);
			}
		});
	}
	
	public void cancelEvent(View view){
		finish();
	}
}
