//	This is javadoc of the Main menu of the app.
//	The user can view all patients in a list view by clicking on "View All Patients" button
//	or enter the health card number of a patient in the edittext field and 
//	view the PatientProfile menu by clicking on "Find Patient" button.

package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private User currentUser;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		Intent intent = getIntent();
		currentUser = (User) intent.getSerializableExtra("user");
		
		if (currentUser.isPhysician()){
			Button newPatientBn = (Button) findViewById(R.id.addnewpatient);
			newPatientBn.setVisibility(View.INVISIBLE);
		}
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		
		TextView header = (TextView) findViewById(R.id.header);
		header.setTypeface(helv);
		header.setTextSize(36);

		
	}

	
	
	public void viewallpatient(View view) {
		// Specifies the next Activity to move to: PatientList.
		 Intent intent = new Intent(this, PatientList.class);
		 intent.putExtra("user", currentUser);
		 startActivity(intent); // Starts PatientList activity.
	}
	
	
	public void addnewpatient(View view) {
		// Specifies the next Activity to move to: PatientList.
		 Intent intent = new Intent(this, NewPatientRecord.class);
		 intent.putExtra("user", currentUser);
		 startActivity(intent); // Starts PatientList activity.
	}
	
	public void logoff(View view) {
		// Specifies the next Activity to move to: PatientList.
		 Intent intent = new Intent(this, LoginActivity.class);
		 finish();
		 startActivity(intent); // Starts PatientList activity.
	}
	
	
	public void viewprofile(View view) {
		
		Intent intent = new Intent(this, PatientProfile.class);

		EditText hcntext = (EditText) findViewById(R.id.typehcn);
		String hcn = hcntext.getText().toString();
		if (!hcn.matches("^\\d{6}$")){
			String msg = "Invalid Health Card Number";
			Toast.makeText(MainActivity.this,msg,Toast.LENGTH_LONG).show();
			return;
		}

		intent.putExtra("patient", currentUser.getPatient(hcn));
		intent.putExtra("user", currentUser);

		startActivity(intent); 
	}
	
	
	
}
