package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
//	    this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

		setContentView(R.layout.activity_login);
		
		AppConstant.p_records_path = getFilesDir() + "/patient_records.txt";
		AppConstant.v_records_path = getFilesDir() + "/visit_records.txt";
		AppConstant.d_records_path = getFilesDir() + "/doctor_records.txt";
		AppConstant.prescriptions_path = getFilesDir() + "/prescriptions.txt";
		AppConstant.passwords_path = getFilesDir() + "/passwords.txt";
		
		
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		Typeface acc = Typeface.createFromAsset(getAssets(),"fonts/AccidentalPresidency.ttf"); 
		
		TextView loginbutton = (TextView) findViewById(R.id.loginbutton);
		loginbutton.setTypeface(helv);
		loginbutton.setTextSize(36);
		
		TextView username = (TextView) findViewById(R.id.editText1);
		username.setTypeface(helv);
		username.setTextSize(24);
		
		TextView password = (TextView) findViewById(R.id.editText2);
		password.setTypeface(helv);
		password.setTextSize(24);
	}


	
	public void viewUser(View view){
		// Specifies the next Activity to move to: MainActicity.
		Intent intent = new Intent(this, MainActivity.class);
		
		EditText nameText = (EditText) findViewById(R.id.editText1);
		String username = nameText.getText().toString();
		
		EditText pwText = (EditText) findViewById(R.id.editText2);
		String password = pwText.getText().toString();

		User user = new User();
		String[] account = new String[] {username,password};
		String msg = user.checkAccount(account);
		if(msg.equals("Correct")){
			String type = user.getAccountType(account).trim();
			if (type.equals("nurse")){ intent.putExtra("user", new Nurse());}
			else if (type.equals("physician")){ intent.putExtra("user", new Physician());}
			startActivity(intent);// Starts MainActivity activity.
		}
		else{
//			TextView message = (TextView) findViewById(R.id.msgText);
//			message.setText(msg);
//			message.setGravity(Gravity.CENTER_HORIZONTAL);
//			String sss = "Viewing the Current Prescription of ";
			Toast.makeText(LoginActivity.this,msg,Toast.LENGTH_LONG).show();

		}
		
		
	}
}
