package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

public class NewPrescription extends Activity {
	
	private Physician currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_new_prescription);
		
		Intent intent = getIntent();
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		currentUser = (Physician) intent.getSerializableExtra("user");
		
		String hcn =  thisPatient.getInfo()[0];
		String name = thisPatient.getInfo()[1];
		TextView header = (TextView) findViewById(R.id.title_new_prescription);
		header.setText("Presciption \n" + hcn + " " + name);

		this.createPrescription(thisPatient);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.new_prescription, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void createPrescription(final Patient thisPatient){
		
		Button bn = (Button) findViewById(R.id.createbutton);
		bn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText medicationText = (EditText) findViewById(R.id.medication_hint);
				String medication = medicationText.getText().toString();
				
				EditText instructionText = (EditText) findViewById(R.id.description_instruction_hint);
				String instruction = instructionText.getText().toString();
				
				if (!medication.isEmpty() && !instruction.isEmpty()){
					currentUser.updatePrescription(thisPatient.getInfo()[0], medication, instruction);
				}else if (medication.isEmpty() && instruction.isEmpty()){
				}else {
					Toast.makeText(NewPrescription.this,"Please Fill out the empty field",Toast.LENGTH_LONG).show();
					return;
				}
				
				Intent intent = new Intent(NewPrescription.this, PatientProfile.class);
				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);
				finish();
				startActivity(intent);
			}
		});
		
	}
	
	public void cancelEvent(View v){
		finish();
	}
}

