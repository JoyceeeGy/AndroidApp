//	This is the menu of PatientList which contains a list of all patients.
//	
//	In this menu, user can view a list that contains all the patients,
//	each item of the list contains one patient with his/her 
//	health card number, name and date of birth.
//	
//	By click each item of the list(each patient), 
//	the app will open a menu of that patient's PatientProfile.
//			
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PatientList extends Activity {

	private User currentUser;
	private boolean listsorted = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_patient_list);
		
		Intent intent = getIntent();
		currentUser = (User) intent.getSerializableExtra("user");

		populatelist();
		viewprofile ();
		returnactivity();
		Sortlist();
		
		if (currentUser.isPhysician()){
			Button Sortlistbutton = (Button) findViewById(R.id.sortlist);
			Sortlistbutton.setVisibility(View.INVISIBLE);
		}
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		
		TextView patientlistheader = (TextView) findViewById(R.id.patientlistheader);
		patientlistheader.setTypeface(helv);
		patientlistheader.setTextSize(36);

		
		TextView returnactivity = (TextView) findViewById(R.id.returnactivity);
		returnactivity.setTypeface(helv);
		returnactivity.setTextSize(18);
		
		TextView sortlist = (TextView) findViewById(R.id.sortlist);
		sortlist.setTypeface(helv);
		sortlist.setTextSize(24);

		
	  }
		
	
	private void populatelist() {
		ListView list = (ListView) findViewById(R.id.patientlist);
		ArrayList<String> pRecordsAL = new ArrayList<String>();
		Button Sortlistbutton = (Button) findViewById(R.id.sortlist);
		
		if (listsorted){
			Nurse currentNurse = (Nurse) currentUser;
			pRecordsAL = currentNurse.getToHelpPatients();
			Sortlistbutton.setText("Unsort");
			}
		
		else{
			String [][] data = currentUser.getPatientsData();
			
			String temp = "";
			for (String[] arr: data){
				temp = "";
				for (String s: arr){ temp += s + "  ";}
				pRecordsAL.add(temp);
			}
			Sortlistbutton.setText("Sort");
			}
		
		ArrayAdapter<String> pladapter = new ArrayAdapter<String>(this,R.layout.patientinlist,pRecordsAL);
		list.setAdapter(pladapter);
	}
		

	
	
	private void viewprofile () {
		ListView list = (ListView) findViewById(R.id.patientlist);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			//@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				TextView txtView = (TextView) view;
				String hcn = txtView.getText().toString().split(" ")[0];
				
				String message = "Viewing profile of "+ txtView.getText().toString();
				Toast.makeText(PatientList.this,message,Toast.LENGTH_LONG).show();
				
				
				Intent intent = new Intent(PatientList.this, PatientProfile.class);
				intent.putExtra("patient", currentUser.getPatient(hcn));
				intent.putExtra("user", currentUser);
				startActivity(intent);
			}
		});
	}
	
	
	private void Sortlist () {
		Button Sortlistbutton = (Button) findViewById(R.id.sortlist);
		Sortlistbutton.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
				
			    String message = "Showing the List of ";
				if (listsorted){
					listsorted = false;
					Toast.makeText(PatientList.this,message + "All Patients",Toast.LENGTH_LONG).show();
				}
				else{
					listsorted = true;
					Toast.makeText(PatientList.this,message + "Patients Who Haven't Seen by A Doctor",Toast.LENGTH_LONG).show();
				}
				
				populatelist();
			}
		});
	}
	
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
	
}
