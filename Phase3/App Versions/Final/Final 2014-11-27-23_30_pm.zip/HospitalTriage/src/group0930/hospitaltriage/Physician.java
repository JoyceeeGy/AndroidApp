package group0930.hospitaltriage;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

/**
 * A User with the authority of a nurse
 */

public class Physician extends User {

	private static final long serialVersionUID = -7603523968177861647L;

	/**
	 * Updates prescription with medication and instruction for a patient who 
	 * has a health card number of healthCardNum.
	 * @param healthCardNum the health card number of a patient
	 * @param medication the name of medication 
	 * @param instruction the description of instruction
	 */
	public void updatePrescription(String healthCardNum, String medication, String instruction){
		try {
			File fr = new File(AppConstant.prescriptions_path);
			RandomAccessFile raf = new RandomAccessFile(fr, "rw");
			
			// Search for the startpoint of this Patient's prescription
			String line = raf.readLine();
			while (!line.equals(healthCardNum)){
				line = raf.readLine();
				// Create a new prescriptoin record for healthCardNum
				if (line == null){
					raf.writeBytes("\n" + healthCardNum);
					raf.writeBytes("\n" + medication);
					raf.writeBytes("\n" + instruction);
					raf.close();
					return;
				}
			} 
			
			long marker = raf.getFilePointer(); 
			//Skip this Patient's previous prescription
			while(line != null && line.length() != 6){ line = raf.readLine(); }
			// copy rest of the file
			ArrayList<String> restFile = new ArrayList<String>();
			while (line != null) {
				restFile.add(line);
				line = raf.readLine();
			}
			
			String toWrite;
			raf.seek(marker - 1);
			toWrite = "\n" + medication;
			raf.write(toWrite.getBytes());
			toWrite = "\n" + instruction;
			raf.write(toWrite.getBytes());
			
			int ind = 0;
			int size = restFile.size();
			while (ind < size) {
				toWrite = "\n" + restFile.get(ind);
				raf.write(toWrite.getBytes());
				ind ++;
			}raf.close();
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean isPhysician(){
		return true;
	}
}

