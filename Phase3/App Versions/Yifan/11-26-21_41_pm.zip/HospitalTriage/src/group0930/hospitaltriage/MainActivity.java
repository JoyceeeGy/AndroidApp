//	This is javadoc of the Main menu of the app.
//	The user can view all patients in a list view by clicking on "View All Patients" button
//	or enter the health card number of a patient in the edittext field and 
//	view the PatientProfile menu by clicking on "Find Patient" button.

package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	
	private User currentUser;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Intent intent = getIntent();
		currentUser = (User) intent.getSerializableExtra("user");
		
		if (currentUser.isPhysician()){
			Button newPatientBn = (Button) findViewById(R.id.addnewpatient);
			newPatientBn.setVisibility(View.INVISIBLE);
		}
	}

	
	
	public void viewallpatient(View view) {
		// Specifies the next Activity to move to: PatientList.
		 Intent intent = new Intent(this, PatientList.class);
		 intent.putExtra("user", currentUser);
		 startActivity(intent); // Starts PatientList activity.
	}
	
	
	public void addnewpatient(View view) {
		// Specifies the next Activity to move to: PatientList.
		 Intent intent = new Intent(this, NewPatientRecord.class);
		 intent.putExtra("user", currentUser);
		 startActivity(intent); // Starts PatientList activity.
	}
	
	public void logoff(View view) {
		// Specifies the next Activity to move to: PatientList.
		 Intent intent = new Intent(this, LoginActivity.class);
		 finish();
		 startActivity(intent); // Starts PatientList activity.
	}
	
	
	public void viewprofile(View view) {
		
		Intent intent = new Intent(this, PatientProfile.class);

		EditText hcntext = (EditText) findViewById(R.id.typehcn);
		String hcn = hcntext.getText().toString();

		intent.putExtra("patient", currentUser.getPatient(hcn));
		intent.putExtra("user", currentUser);

		startActivity(intent); 
	}
	
	
	
}
