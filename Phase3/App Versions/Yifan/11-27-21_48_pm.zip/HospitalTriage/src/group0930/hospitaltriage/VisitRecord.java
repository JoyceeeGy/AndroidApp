//	This is the menu of VisitRecord which contains specific information 
//	of one single visit record of a patient.
//	
//	In this menu, the app shows the specific information of one single visit record of a patient,
//	including:	Date of visit,
//				Age
//				Temperature
//				Systolic Blood Rate
//				Diastolic Blood Rate
//				Heart Rate
//				Urgency Level
//				
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;



import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

public class VisitRecord extends Activity {

	private User currentUser;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_visit_record);
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		String dateOfRecord = (String) intent.getSerializableExtra("dateOfRecord");
		
		populatelist(thisPatient, dateOfRecord);
		
		returnactivity();	

	}

	private void populatelist(Patient thisPatient, String dateOfRecord) {

		String name = thisPatient.getInfo()[1];
		String[] visitRecord = thisPatient.getVisitRecord(dateOfRecord);
		String urgencylvl = thisPatient.urgentLevel(visitRecord);
		// Setting thisPatient's info on the View
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		
		TextView returnactivity = (TextView) findViewById(R.id.returnactivity);
		returnactivity.setTypeface(helv);
		returnactivity.setTextSize(20);
		
		TextView header = (TextView) findViewById(R.id.headerofonerecord);
		header.append("\n"+name+"\nDate:  "+ visitRecord[0]);
		header.setTypeface(helv);
		header.setTextSize(18);
		
		
		TextView arrivaltime = (TextView) findViewById(R.id.arrivaltime);
		arrivaltime.append("  "+  visitRecord[1]);
		arrivaltime.setTypeface(helv);
		arrivaltime.setTextSize(16);
		
		TextView age = (TextView) findViewById(R.id.age);
		age.append("  "+  visitRecord[2]);
		age.setTypeface(helv);
		age.setTextSize(16);
		
		TextView temp = (TextView) findViewById(R.id.temp);
		temp.append("  "+  visitRecord[3]);
		temp.setTypeface(helv);
		temp.setTextSize(16);
		
		TextView sblood = (TextView) findViewById(R.id.sblood);
		sblood.append("  "+  visitRecord[4]);
		sblood.setTypeface(helv);
		sblood.setTextSize(16);
		
		TextView dblood = (TextView) findViewById(R.id.dblood);
		dblood.append("  "+  visitRecord[5]);
		dblood.setTypeface(helv);
		dblood.setTextSize(16);
		
		TextView heartrate = (TextView) findViewById(R.id.heartrate);
		heartrate.append("  "+  visitRecord[6]);
		heartrate.setTypeface(helv);
		heartrate.setTextSize(16);
		
		TextView urgencylevel = (TextView) findViewById(R.id.urgencylvl);
		urgencylevel.append("  "+  urgencylvl);
		urgencylevel.setTypeface(helv);
		urgencylevel.setTextSize(16);
	
	}
	
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
	
	
	
}
