//	This is the menu of NewVisitRecord that allows a user to create a new visit record for a patient.
//	
//	In this menu, user creates a new visit record for a patient by entering some specific information,
//	including:	Date of visit,
//				Age
//				Temperature
//				Systolic Blood Rate
//				Diastolic Blood Rate
//				Heart Rate
//				Urgency Level
//	
//	This menu contains a Cancel button that allows user to 
//	cancel the creating process and discard the information entered.


package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class NewVisitRecord extends Activity {

	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_new_visit_record);
		
		Intent intent = getIntent();
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		
		String hcn = thisPatient.getInfo()[0];
		String name = thisPatient.getInfo()[1]; 
		TextView Title = (TextView) findViewById(R.id.title_new_visit_record);
		Title.setText("Create New Visit Record\n" + name+"("+hcn+")");
		
		createrecord(thisPatient);
		returnactivity();
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 

		Title.setTypeface(helv);
		Title.setTextSize(20);
		
		TextView createbutton = (TextView) findViewById(R.id.createbutton);
		createbutton.setTypeface(helv);
		createbutton.setTextSize(20);
		
		TextView cancelbutton = (TextView) findViewById(R.id.cancelbutton);
		cancelbutton.setTypeface(helv);
		cancelbutton.setTextSize(20);
		
	}
	
	public void createrecord(final Patient thisPatient){
		
		Button addrecord = (Button) findViewById(R.id.createbutton);
		addrecord.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				
				String[] visit_record = new String[7];
				String msg = "Invalid Format for ";
				
				EditText visitdatetxt = (EditText) findViewById(R.id.visit_dateenter);
				String visitdate = visitdatetxt.getText().toString();
				if (!visitdate.matches("^\\d{4}-\\d{2}-\\d{2}$")){
					msg += "Visit Date";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText timetxt = (EditText) findViewById(R.id.arrivaltime_enter);
				String time = timetxt.getText().toString();
				if (!time.matches("^\\d{2}-\\d{2}$")){
					msg += "Arrival Time";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText agetxt = (EditText) findViewById(R.id.ageenter);
				String age = agetxt.getText().toString();
				if (!age.matches("^\\d{2}$")){
					msg += "Age";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText temptxt = (EditText) findViewById(R.id.tempenter);
				String temp = temptxt.getText().toString();
				if (!temp.matches("^\\d*\\.?\\d*$")){
					msg += "Temperature";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText sbloodtxt = (EditText) findViewById(R.id.sbloodenter);
				String sblood = sbloodtxt.getText().toString();
				if (!sblood.matches("^\\d*\\.?\\d*$")){
					msg += "Systolic Blood Pressure";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText dbloodtxt = (EditText) findViewById(R.id.dbloodenter);
				String dblood = dbloodtxt.getText().toString();
				if (!dblood.matches("^\\d*\\.?\\d*$")){
					msg += "Diastolic Blood Pressure";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				EditText heartratetxt = (EditText) findViewById(R.id.heartrateenter);
				String heartrate = heartratetxt.getText().toString();
				if (!heartrate.matches("^\\d*\\.?\\d*$")){
					msg += "Heartrate";
					Toast.makeText(NewVisitRecord.this,msg,Toast.LENGTH_LONG).show();
					return;
				}
				
				// Get inputs from EditText(s)，and save them into visit_record as follow
				visit_record[0] = visitdate;
				visit_record[1] = time;
				visit_record[2] = age;
				visit_record[3] = temp;
				visit_record[4] = sblood;
				visit_record[5] = dblood;
				visit_record[6] = heartrate;
				
				// Remember to pass in the Patient object from the Patient Profile activity
				thisPatient.addVisitRecord(visit_record);
					
				// Open a new Patient Profile activity (so the visit records would reload)
				Intent intent = new Intent(NewVisitRecord.this, PatientProfile.class);
				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);
				
				finish();
				startActivity(intent); 
			    }
			});
	}
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.cancelbutton);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}	
	
}
