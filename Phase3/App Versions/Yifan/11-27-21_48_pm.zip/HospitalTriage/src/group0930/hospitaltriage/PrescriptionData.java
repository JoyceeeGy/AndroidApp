package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class PrescriptionData extends Activity {
	
	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_prescription_data);
		
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		
		populatelist(thisPatient);
		addPrescription(thisPatient);
		returnactivity();
		
		if (currentUser.isNurse()){
			Button bn = (Button) findViewById(R.id.updatePrescription);
			ImageView imageadd = (ImageView) findViewById(R.id.imageView2);
			bn.setVisibility(View.INVISIBLE);
			imageadd.setVisibility(View.INVISIBLE);
		}
		
		Typeface helv = Typeface.createFromAsset(getAssets(),"fonts/Helvetica_Bold.ttf"); 
		
		TextView prescription_header = (TextView) findViewById(R.id.prescription_header);
		prescription_header.setTypeface(helv);
		prescription_header.setTextSize(24);
		
		TextView medication = (TextView) findViewById(R.id.medication);
		medication.setTypeface(helv);
		medication.setTextSize(18);
		
		TextView description = (TextView) findViewById(R.id.description);
		description.setTypeface(helv);
		description.setTextSize(18);
		
		TextView blank = (TextView) findViewById(R.id.blank);
		blank.setTypeface(helv);
		blank.setTextSize(16);
		
		TextView updatePrescription = (TextView) findViewById(R.id.updatePrescription);
		updatePrescription.setTypeface(helv);
		updatePrescription.setTextSize(20);
		
		TextView returnactivity = (TextView) findViewById(R.id.returnactivity);
		returnactivity.setTypeface(helv);
		returnactivity.setTextSize(20);
				
	}

	private void populatelist(Patient thisPatient) {
		String name = thisPatient.getInfo()[1];
    	String hcn = thisPatient.getInfo()[0];
    	String[] prescription = thisPatient.getPrescription();
    	
    	TextView header = (TextView) findViewById(R.id.prescription_header);
		header.setText(name+" ("+hcn+")");
		
		TextView medication = (TextView) findViewById(R.id.medication);
		medication.append("  "+  prescription[0]);
		
		TextView blank = (TextView) findViewById(R.id.blank);
		blank.setText(prescription[1]);
	}
	
	public void addPrescription(final Patient thisPatient) {

		Button bn = (Button) findViewById(R.id.updatePrescription);
		bn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent intent = new Intent(PrescriptionData.this,
						NewPrescription.class);

				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);

				finish();
				startActivity(intent);
			}
		});
	}

	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
}
