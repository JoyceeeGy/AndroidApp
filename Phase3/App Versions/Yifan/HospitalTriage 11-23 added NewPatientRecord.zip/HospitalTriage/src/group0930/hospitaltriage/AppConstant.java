package group0930.hospitaltriage;

import android.content.Context;

public class AppConstant {
	public static Context context;
	public static String p_records_path;
	public static String v_records_path;
	public static String d_records_path;
	public static String prescriptions_path;
	public static String passwords_path;
}

