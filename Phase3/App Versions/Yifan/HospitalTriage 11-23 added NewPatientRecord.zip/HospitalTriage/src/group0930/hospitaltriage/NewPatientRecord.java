package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewPatientRecord extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_patient_record);
	}

	
	
	
	
	public void createrecord(final String hcn){
		
		Button addrecord = (Button) findViewById(R.id.addpatient);
		addrecord.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Nurse currentnurse = new Nurse();
				
				String[] patient_record = new String[3];
				
				EditText lastnametxt = (EditText) findViewById(R.id.enterlastname);
				String lastname = lastnametxt.getText().toString();
				
				EditText firstnametxt = (EditText) findViewById(R.id.enterfirstname);
				String firstname = firstnametxt.getText().toString();
				
				EditText dobtxt = (EditText) findViewById(R.id.enterdob);
				String dob = dobtxt.getText().toString();
				
				EditText hcntxt = (EditText) findViewById(R.id.enterhcn);
				String hcn = hcntxt.getText().toString();
				
				String name = firstname + " " + lastname;
				
				// Get inputs from EditText(s)��and save them into patient_record as follow
				patient_record[0] = hcn;
				patient_record[1] = name;
				patient_record[2] = dob;


				
				// Remember to pass in the Patient object from the Patient Profile activity
				currentnurse.addPatientRecord(patient_record);
					
				// Open a new Patient Profile activity (so the visit records would reload)
				Intent intent = new Intent(NewPatientRecord.this, PatientProfile.class);
				intent.putExtra("patientnumber", hcn); 
				startActivity(intent); 
				
			    }
			});
	
	}
}
