package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PrescriptionData extends Activity {
	
	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_prescription_data);
		
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		
		populatelist(thisPatient);
		addPrescription(thisPatient);
		returnactivity();
		
		if (currentUser.isNurse()){
			Button bn = (Button) findViewById(R.id.updatePrescription);
			bn.setVisibility(View.INVISIBLE);
		}
	}

	private void populatelist(Patient thisPatient) {
		String name = thisPatient.getInfo()[1];
    	String hcn = thisPatient.getInfo()[0];
    	String[] prescription = thisPatient.getPrescription();
    	
    	TextView header = (TextView) findViewById(R.id.prescription_header);
		header.setText(name+" ("+hcn+")");
		
		TextView medication = (TextView) findViewById(R.id.medication);
		medication.append("  "+  prescription[0]);
		
		TextView blank = (TextView) findViewById(R.id.blank);
		blank.setText(prescription[1]);
	}
	
	public void addPrescription(final Patient thisPatient) {

		Button bn = (Button) findViewById(R.id.updatePrescription);
		bn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent intent = new Intent(PrescriptionData.this,
						NewPrescription.class);

				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);

				finish();
				startActivity(intent);
			}
		});
	}

	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
}
