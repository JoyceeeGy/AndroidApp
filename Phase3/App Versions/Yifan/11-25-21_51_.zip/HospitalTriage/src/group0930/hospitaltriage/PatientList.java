//	This is the menu of PatientList which contains a list of all patients.
//	
//	In this menu, user can view a list that contains all the patients,
//	each item of the list contains one patient with his/her 
//	health card number, name and date of birth.
//	
//	By click each item of the list(each patient), 
//	the app will open a menu of that patient's PatientProfile.
//			
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PatientList extends Activity {

	private User currentUser;
	private boolean listsorted = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_patient_list);
		
		Intent intent = getIntent();
		currentUser = (User) intent.getSerializableExtra("user");
		
		
		populatelist();
		viewprofile ();
		returnactivity();
		Sortlist();
		
		Button Sortlistbutton = (Button) findViewById(R.id.sortlist);
		if (currentUser.isNurse()){
			Sortlistbutton.setVisibility(View.VISIBLE);
		}
		else{
			Sortlistbutton.setVisibility(View.INVISIBLE);
		}
		
		
	  }
		
	
	private void populatelist() {
		ListView list = (ListView) findViewById(R.id.patientlist);
		ArrayList<String> pRecordsAL = new ArrayList<String>();
		
		
		if (listsorted){
			Nurse currentnurse = (Nurse) currentUser;
//			pRecordsAL = currentnurse.getToHelpPatients();
			ArrayList<String> temp_Arraylist = new ArrayList<String>();
//			temp_Arraylist = currentnurse.getToHelpPatients();
			pRecordsAL.add("testhaha");
			pRecordsAL.add("testhaha22");
			pRecordsAL.add("testhaha333");
			
			}
		
		else{
			String [][] data = currentUser.getPatientsData();
			
			String temp = "";
			for (String[] arr: data){
				temp = "";
				for (String s: arr){
					temp += s + " ";
				}
				pRecordsAL.add(temp);
				}
			}
		
		ArrayAdapter<String> pladapter = new ArrayAdapter<String>(this,R.layout.patientinlist,pRecordsAL);
		list.setAdapter(pladapter);
	}
		

	
	
	private void viewprofile () {
		ListView list = (ListView) findViewById(R.id.patientlist);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			//@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				TextView txtView = (TextView) view;
				String hcn = txtView.getText().toString().split(" ")[0];
				
				String message = "Viewing profile of "+ txtView.getText().toString();
				Toast.makeText(PatientList.this,message,Toast.LENGTH_LONG).show();
				
				
				Intent intent = new Intent(PatientList.this, PatientProfile.class);
				intent.putExtra("patient", currentUser.getPatient(hcn));
				startActivity(intent);
			}
		});
	}
	
	
	private void Sortlist () {
		Button Sortlistbutton = (Button) findViewById(R.id.sortlist);
		Sortlistbutton.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
				
			    String message = "Showing List of ";
				if (listsorted){
					listsorted = false;
					Toast.makeText(PatientList.this,message + "All Patients",Toast.LENGTH_LONG).show();
				}
				else{
					listsorted = true;
					Toast.makeText(PatientList.this,message + "Patients without Doctor Check",Toast.LENGTH_LONG).show();
				}
				
				populatelist();

			}
		});
	}
	
	
	
	
	
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
	
}
