package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DoctorActivity extends Activity {

	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_doctor);
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		
		this.addPrescription(thisPatient);
	}

	
	
	public void addPrescription(final Patient thisPatient) {

		Button bn = (Button) findViewById(R.id.save);
		bn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(DoctorActivity.this,
						NewPrescription.class);

				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);

				startActivity(intent);

			}
		});
	}
	
	public void cancelEvent(View view){
		finish();
	}
}
