//	This is the menu of VisitRecord which contains specific information 
//	of one single visit record of a patient.
//	
//	In this menu, the app shows the specific information of one single visit record of a patient,
//	including:	Date of visit,
//				Age
//				Temperature
//				Systolic Blood Rate
//				Diastolic Blood Rate
//				Heart Rate
//				Urgency Level
//				
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class VisitRecord extends Activity {

	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_visit_record);
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		String dateOfRecord = (String) intent.getSerializableExtra("dateOfRecord");
		
		populatelist(thisPatient, dateOfRecord);
		
		returnactivity();

	}

	private void populatelist(Patient thisPatient, String dateOfRecord) {

		String name = thisPatient.getInfo()[1];
		String[] visitRecord = thisPatient.getVisitRecord(dateOfRecord);
		String urgencylvl = thisPatient.urgentLevel(visitRecord);
		// Setting thisPatient's info on the View
		
		TextView header = (TextView) findViewById(R.id.headerofonerecord);
		header.append("  "+name+"\nDate:"+ visitRecord[0]);
		
		TextView age = (TextView) findViewById(R.id.age);
		age.append("  "+  visitRecord[1]);
		
		TextView temp = (TextView) findViewById(R.id.temp);
		temp.append("  "+  visitRecord[2]);
		
		TextView sblood = (TextView) findViewById(R.id.sblood);
		sblood.append("  "+  visitRecord[3]);
		
		TextView dblood = (TextView) findViewById(R.id.dblood);
		dblood.append("  "+  visitRecord[4]);
		
		TextView heartrate = (TextView) findViewById(R.id.heartrate);
		heartrate.append("  "+  visitRecord[5]);
		
		TextView urgencylevel = (TextView) findViewById(R.id.urgencylvl);
		urgencylevel.append("  "+  urgencylvl);
	
	}
	
	
	public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
	
	
	
	
}
