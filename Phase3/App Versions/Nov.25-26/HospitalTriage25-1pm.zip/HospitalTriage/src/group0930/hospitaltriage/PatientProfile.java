//	This is menu of PatientProfile which contains one patient's profile.
//	
//	In one patient's profile, it shows the patients basic information and visit records.
//	The basic information contains health card number, name and date of birth.
//	The visit records is showed in a list view which contains information 
//	date of visit and urgency level.
//	
//	By clicking on each item of the visit records list(each record), 
//	another menu of VisitRecord which contains specific informations of that visit record will open.  
//	
//	By clicking on the "+" button on the bottom of this menu,
//	another menu of NewVisitRecord which allows user to create new visit record of that patient will open.
//				
//	This menu contains a Return button that allows user to return to the previous menu.

package group0930.hospitaltriage;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class PatientProfile extends Activity {

	private User currentUser;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_patient_profile);
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");	
		
		populatelist(thisPatient);
		viewrecord(thisPatient);
		
		returnactivity();
		addnewrecord(thisPatient);
		
		this.addDoctorRecord(thisPatient);
	}
	
	
	private void populatelist(Patient thisPatient) {

		// Setting thisPatient's info on the View
		String[] info = thisPatient.getInfo();
		TextView hcdTxtV = (TextView) findViewById(R.id.hcn);
		hcdTxtV.append("  "+info[0]);
		TextView nameTxtV = (TextView) findViewById(R.id.name);
		nameTxtV.append("  "+info[1]);
		TextView dobTxtV = (TextView) findViewById(R.id.dob);
		dobTxtV.append("  "+info[2]);
		
		// Setting thisPatient's visit records on the View
		String [][] data = thisPatient.getVisitRecords();

		ArrayList<String> vRecordsAL = new ArrayList<String>();
		String temp = "";
		for (String[] arr: data){
			temp = "";
			temp += arr[0] + "  " + thisPatient.urgentLevel(arr);
			vRecordsAL.add(temp);
		}

		ArrayAdapter<String> ppadapter = new ArrayAdapter<String>(this,R.layout.recordinlist, vRecordsAL);
		ListView list = (ListView) findViewById(R.id.recordlist);
		list.setAdapter(ppadapter);
	}
	
	
	private void viewrecord (final Patient thisPatient) {
		ListView list = (ListView) findViewById(R.id.recordlist);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			//@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				Intent intent = new Intent(PatientProfile.this, VisitRecord.class);
				
				TextView txt = (TextView) view;
				String temp = txt.getText().toString();
				String[] temps = temp.split(" ");
				String dateOfRecord = temps[0];
				
				intent.putExtra("dateOfRecord", dateOfRecord);
				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);

				String message = "Viewing Visit Record on "+ dateOfRecord;
				Toast.makeText(PatientProfile.this,message,Toast.LENGTH_LONG).show();
				startActivity(intent); 
			}
		});
	}
	

	public void addnewrecord(final Patient thisPatient){
			Button addrecord = (Button) findViewById(R.id.addrecord);
			addrecord.setOnClickListener(new View.OnClickListener() {
				    public void onClick(View v) {
				    	String name = thisPatient.getInfo()[1];
				    	String hcn = thisPatient.getInfo()[0];
				        String message = "Adding new record for "+ name+"(" + hcn + ")";
						Toast.makeText(PatientProfile.this,message,Toast.LENGTH_LONG).show();
						
						Intent intent = new Intent(PatientProfile.this, NewVisitRecord.class);
				        intent.putExtra("patient", thisPatient);
				        intent.putExtra("user", currentUser);
						startActivity(intent); 
				        
				    }
				});
	}
	
	
   public void addDoctorRecord(final Patient thisPatient){
	   
	   Button bn = (Button) findViewById(R.id.addDoctorRecord);
	   bn.setOnClickListener(new View.OnClickListener() {
		
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(PatientProfile.this, 
						DoctorActivity.class);
				intent.putExtra("patient", thisPatient);
		        intent.putExtra("user", currentUser);
				startActivity(intent);
			}
		});
   }
	
   
   public void returnactivity(){
		Button returnactivity = (Button) findViewById(R.id.returnactivity);
		returnactivity.setOnClickListener(new View.OnClickListener() {
			    public void onClick(View v) {
			        finish();
			    }
			});
	}
}
