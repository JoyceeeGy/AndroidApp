package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		AppConstant.p_records_path = getFilesDir() + "/patient_records.txt";
		AppConstant.v_records_path = getFilesDir() + "/visit_records.txt";
		AppConstant.d_records_path = getFilesDir() + "/doctor_records.txt";
		AppConstant.prescriptions_path = getFilesDir() + "/prescriptions.txt";
		AppConstant.passwords_path = getFilesDir() + "/passwords.txt";
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void viewUser(View view){
		// Specifies the next Activity to move to: MainActicity.
		Intent intent = new Intent(this, MainActivity.class);
		
		EditText nameText = (EditText) findViewById(R.id.editText1);
		String username = nameText.getText().toString();
		
		EditText pwText = (EditText) findViewById(R.id.editText2);
		String password = pwText.getText().toString();

		User user = new User();
		String[] account = new String[] {username,password};
		String msg = user.checkAccount(account);
		if(msg.equals("Correct")){
			String type = user.getAccountType(account).trim();
			if (type.equals("nurse")){ intent.putExtra("user", new Nurse());}
			else if (type.equals("physician")){ intent.putExtra("user", new Physician());}
			startActivity(intent);// Starts MainActivity activity.
		}
		else{
			TextView message = (TextView) findViewById(R.id.msgText);
			message.setText(msg);
			message.setGravity(Gravity.CENTER_HORIZONTAL);
		}
		
		
	}
}
