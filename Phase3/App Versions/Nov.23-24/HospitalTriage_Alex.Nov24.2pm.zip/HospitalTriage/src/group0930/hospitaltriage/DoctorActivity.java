package group0930.hospitaltriage;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class DoctorActivity extends Activity {

	private User currentUser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_doctor);
		Intent intent = getIntent();
		
		currentUser = (User) intent.getSerializableExtra("user");
		Patient thisPatient = (Patient) intent.getSerializableExtra("patient");
		
		this.addPrescription(thisPatient);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.doctor, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void addPrescription(final Patient thisPatient) {

		Button bn = (Button) findViewById(R.id.addprescription);
		bn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(DoctorActivity.this,
						NewPrescription.class);

				intent.putExtra("patient", thisPatient);
				intent.putExtra("user", currentUser);

				startActivity(intent);

			}
		});
	}
	
	public void cancelEvent(View view){
		finish();
	}
}
