package group0930.hospitaltriage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

/**
 * A User with the authority of a nurse
 */

public class Physician extends User {

	public String[] getPrescription(String healthCardNum){
		try {
			FileReader fr = new FileReader(new File(AppConstant.prescriptions_path));
            BufferedReader br = new BufferedReader(fr);
            String[] prescription = new String[2];
            
			// Find the prescription of this Patient
            String line  = br.readLine();
			while (!(line.trim().equals(healthCardNum))){
				if (line == ""){
					br.close();
					return new String[]{"None", "No presciption available"};
				}line = br.readLine();
			} 
			line = br.readLine();
			prescription[0] = line.trim();
			String instruction = "";
			while (line != null && line.length() != 6){
				instruction += line + "\n";
				line = br.readLine();
			}
			prescription[1] = instruction.substring(0, instruction.length()-1);
			br.close();
			return prescription;
		}catch (IOException e){
			e.printStackTrace();
			return new String[]{"None", "No presciption available"};
		}
			
	}
	
	public void updatePrescription(String healthCardNum, String medication, String instruction){
		try {
			File fr = new File(AppConstant.prescriptions_path);
			RandomAccessFile raf = new RandomAccessFile(fr, "rw");
			
			// Search for the startpoint of this Patient's prescription
			String line = raf.readLine();
			while (line != null && !line.equals(healthCardNum)){
				line = raf.readLine();
			} if (line == null){
				raf.write(healthCardNum.getBytes());
			}
			
			long marker = raf.getFilePointer(); 
			//Skip this Patient's previous prescription
			line = raf.readLine();
			while(line != null && line.length() != 6){ line = raf.readLine(); }
			// copy rest of the file
			ArrayList<String> restFile = new ArrayList<String>();
			line = raf.readLine();
			while (line != null) {
				restFile.add(line);
				line = raf.readLine();
			}
			
			String toWrite;
			raf.seek(marker - 1);
			toWrite = "\n" + medication;
			raf.write(toWrite.getBytes());
			toWrite = "\n" + instruction;
			raf.write(toWrite.getBytes());
			
			int ind = 0;
			int size = restFile.size();
			while (ind < size) {
				toWrite = "\n" + restFile.get(ind);
				raf.write(toWrite.getBytes());
				ind ++;
			}raf.close();
		}catch (IOException e){
			e.printStackTrace();
		}
	}
}

